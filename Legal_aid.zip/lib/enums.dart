enum AuthMode { signup, login }
