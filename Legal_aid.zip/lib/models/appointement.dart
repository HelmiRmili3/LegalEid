// class Appointement {
//   String id;
//   String time;
//   String date;
//   String details;
//   Appointement(
//     this.id,
//     this.time,
//     this.date,
//     this.details,
//   );
// }
