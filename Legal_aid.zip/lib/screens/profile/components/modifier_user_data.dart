// import 'package:flutter/material.dart';

// class ModifierUserData extends StatelessWidget {
//   const ModifierUserData({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Modifer user data'),
//       ),
//       body: Container(
//         padding: const EdgeInsets.all(20),
//         child: Form(
//             child: Column(
//           children: [
//             TextFormField(
//               //focusNode:myFocusNode,
//               autovalidateMode: AutovalidateMode.onUserInteraction,
//               //controller: _emailTextController,
//               decoration: const InputDecoration(
//                 focusedBorder: OutlineInputBorder(
//                   borderSide: BorderSide(
//                     width: 2,
//                     color: Colors.blueAccent,
//                   ),
//                 ),
//                 prefixIcon: Icon(Icons.person),
//                 border: OutlineInputBorder(
//                   borderRadius: BorderRadius.all(
//                     Radius.circular(8),
//                   ),
//                 ),
//                 labelText: 'Name',
//               ),
//             ),
//             const SizedBox(height: 10,),
//             TextFormField(
//               //focusNode:myFocusNode,
//               autovalidateMode: AutovalidateMode.onUserInteraction,
//               //controller: _emailTextController,
//               decoration: const InputDecoration(
//                 focusedBorder: OutlineInputBorder(
//                   borderSide: BorderSide(
//                     width: 2,
//                     color: Colors.blueAccent,
//                   ),
//                 ),
//                 prefixIcon: Icon(Icons.person),
//                 border: OutlineInputBorder(
//                   borderRadius: BorderRadius.all(
//                     Radius.circular(8),
//                   ),
//                 ),
//                 labelText: 'Phone',
//               ),
//             ),
//             const SizedBox(height: 10,),
//             TextFormField(
//               //focusNode:myFocusNode,
//               autovalidateMode: AutovalidateMode.onUserInteraction,
//               decoration: const InputDecoration(
//                 focusedBorder: OutlineInputBorder(
//                   borderSide: BorderSide(
//                     width: 2,
//                     color: Colors.blueAccent,
//                   ),
//                 ),
//                 prefixIcon: Icon(Icons.person),
//                 border: OutlineInputBorder(
//                   borderRadius: BorderRadius.all(
//                     Radius.circular(8),
//                   ),
//                 ),
//                 labelText: 'address',
//               ),
//             )
//           ],
//         )),
//       ),
//     );
//   }
// }
